package Inicio;
import Ventanas.Login;

public class Principal {

	//ENTRADA A LA APLICACI�N
	public static void main(String[] args) {
				
		//Ventanas a utilizar	
		Login vPlayer = new Login();
		vPlayer.setVisible(true);
	}
}
